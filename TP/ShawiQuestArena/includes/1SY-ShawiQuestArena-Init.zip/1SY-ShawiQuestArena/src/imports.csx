// Généré automatiquement par HKAutomator.csx.
// Ne pas modifier manuellement.

#load "Classes/AttackBuilder.csx"
#load "Classes/GameSettings.csx"
