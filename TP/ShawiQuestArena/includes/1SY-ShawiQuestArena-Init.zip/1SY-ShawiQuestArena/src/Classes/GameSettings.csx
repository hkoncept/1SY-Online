public enum EnchantmentType
{
  Fiery = 0,
  Crusader = 1,
  Berzerking = 2,
}

public enum WeaponType
{
  QuelSerrar = 0,
  ArcaniteReaper = 1,
  Shadowmourne = 2,
}

public static class GameSettings
{
  /// <summary>
  /// Paramètres généraux du jeu
  /// </summary>

  // Utilisez les settings de l'énoncé ici
}
