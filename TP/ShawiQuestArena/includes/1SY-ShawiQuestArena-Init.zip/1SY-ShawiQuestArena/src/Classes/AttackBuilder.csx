class AttackBuilder
{

}
