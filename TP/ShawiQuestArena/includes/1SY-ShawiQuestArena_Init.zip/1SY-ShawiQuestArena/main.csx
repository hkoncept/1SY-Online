#load "src/imports.csx"

//Exemple d'utilisation de la classe GameSettings
Console.WriteLine(GameSettings.General.PlayerCount); // Affiche 2
Console.WriteLine(GameSettings.Weapon.ArcaniteReaper.HitChance); // Affiche 0.5
