/// <summary>
/// Classe pour construire des attaques dans le jeu
/// </summary>
class AttackBuilder
{

}
